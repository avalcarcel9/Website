########################
# Alessandra Valcarcel
# November 26, 2018
# Example 3 Batch Job with Parallelization
#######################

# Run the bsub command commented out below to run this code 
# as a batch job after puting the script on the cluster
## Note \ in bash forces the command to the next line without interruption
## Note spaces are still needed after a line since the skip is exact using \
## Output hack
# cp /project/taki3/amv/cluster/normal_session_examples/normal_example3/example3_output.txt /project/taki3/amv/cluster/normal_session_examples/normal_example3/example3_output_previous.txt
# rm /project/taki3/amv/cluster/normal_session_examples/normal_example3/example3_output.txt
# bsub -q cceb_normal \
# -n 50 \
# -J "norm3[1]%1" \
# -R "rusage[mem=500]" \
# -M 1000 \
# -o /project/taki3/amv/cluster/normal_session_examples/normal_example3/example3_output.txt \
# Rscript /project/taki3/amv/cluster/normal_session_examples/normal_example3/normal_example3.R

library(lme4)
library(parallel)

normal_example3 <- function(i, wd = '/project/taki3/amv/cluster/') {
  message('Number of cores detected ', Sys.getenv('LSB_DJOB_NUMPROC'))
  message(paste0('Sampling data for iter ', i))
  # Randomly sample without replacement iris data
  iris_sample = dplyr::sample_n(tbl = iris, size = 75, replace = FALSE)
  message(paste0('Calculating model for iter ', i))
  # Fit linear mixed effects model
  model = lm(Petal.Width ~ Petal.Length + Sepal.Width + Sepal.Length, data = iris_sample)
  # If the directory doesn't exist for job create it
  if(dir.exists(paste0(wd, 'linear_models')) == FALSE){
    dir.create(paste0(wd, 'linear_models'))
  }
  message(paste0('Saving model for iter ', i))
  # Save each iteration of results
  saveRDS(object = model, file = paste0(wd, "linear_models/model_norm1_session_", i, ".rds"))
  message(paste0('Completed iter ', i))
  # Return the fitted model
  return(model)
}

# Set a master seed
set.seed(23)

# Run the example function 100 times
parallel::mclapply(1:100, normal_example3, wd = '/project/taki3/amv/cluster/', mc.cores = as.numeric(Sys.getenv('LSB_DJOB_NUMPROC')))

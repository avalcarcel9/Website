########################
# Alessandra Valcarcel
# November 26, 2018
# Example 2 Batch Job with Parallelization
#######################

# Run the bsub command commented out below to run this code 
# as a batch job after puting the script on the cluster
## Note \ in bash forces the command to the next line without interruption
## Note spaces are still needed after a line since the skip is exact using \
## Output hack
# cp /project/taki3/amv/cluster/normal_session_examples/normal_example2/example2_output.txt /project/taki3/amv/cluster/normal_session_examples/normal_example2/example2_output_previous.txt
# rm /project/taki3/amv/cluster/normal_session_examples/normal_example2/example2_output.txt
# bsub -q cceb_normal \
# -n 2 \
# -J "norm2[1-100]%20" \
# -R "rusage[mem=500]" \
# -M 1000 \
# -o /project/taki3/amv/cluster/normal_session_examples/normal_example2/example2_output.txt \
# Rscript /project/taki3/amv/cluster/normal_session_examples/normal_example2/normal_example2.R

library(lme4)
library(parallel)

normal_example2 <- function(i, wd = '/project/taki3/amv/cluster/') {
  message('Number of cores detected ', Sys.getenv('LSB_DJOB_NUMPROC'))
  message(paste0('Sampling data for iter ', i))
  # Randomly sample without replacement iris data
  iris_sample = dplyr::sample_n(tbl = iris, size = 75, replace = FALSE)
  message(paste0('Calculating model for iter ', i))
  # Fit linear mixed effects model
  model = lm(Petal.Width ~ Petal.Length + Sepal.Width + Sepal.Length, data = iris_sample)
  # If the directory doesn't exist for job create it
  if(dir.exists(paste0(wd, 'linear_models')) == FALSE){
    dir.create(paste0(wd, 'linear_models'))
  }
  message(paste0('Saving model for iter ', i))
  # Save each iteration of results
  saveRDS(object = model, file = paste0(wd, "linear_models/model_norm1_session_", i, ".rds"))
  message(paste0('Completed iter ', i))
  # Return the fitted model
  return(model)
}

# Set a master seed
set.seed(23)
# Create a vector of seeds for the normal batch job
i = as.numeric(Sys.getenv("LSB_JOBINDEX"))
# If i = 0 set it to 1
# Useful for when you're de-bugging code in an interactive session where i is set to 0
if(i == 0){
  i = 1
}

# Create a vector of seeds for array job
iter = 100
seed_vec = sample(1:100000, iter, replace=F)
# Set the seed specific to this task
set.seed(seed_vec[i])

# Run the example function
parallel::mclapply(i, normal_example2, wd = '/project/taki3/amv/cluster/', mc.cores = as.numeric(Sys.getenv('LSB_DJOB_NUMPROC')))
